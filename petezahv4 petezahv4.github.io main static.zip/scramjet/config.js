const _CONFIG = {
	wispurl: "wss://aluu.xyz/wisp/",
	bareurl: "https://aluu.xyz/bare/",
};
