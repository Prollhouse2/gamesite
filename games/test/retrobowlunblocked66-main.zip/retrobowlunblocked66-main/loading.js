<html xmlns="https://loserboysonyt.github.io/">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<META HTTP-EQUIV="pragma" CONTENT="no-cache">
<style>
a:link {text-decoration: none;}
a:visited {text-decoration:none;}
a:hover  {text-decoration:none;}
a:active {text-decoration:none;}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Loading</title>
</head>
<body bgcolor=black onLoad="location.href = url;" style='overflow:hidden;overflow-y:hidden'>
<div class="linear">
<script language="JavaScript">
var url = 'https://loserboysonyt.github.io/';
</script>
    <div align=center style="position: absolute;   
    height:200px;
    top:50%;  
    margin-top:-100px; ">
	<span>Loading...Please wait a moment.<p><a href="https://loserboysonyt.github.io/">Click here to enter directly&gt;&gt;</a></span>
		<style>.proccess{width:2%;height:1%;background:#fff;border-style:none;}a{color:#000}span{color:#000}</style>
	<div align="center">
		<form method=post name=proccess>
<script language=javascript>
for(i=0;i<27;i++)document.write("<input class='proccess' disabled>")
</script>
		</form>
    </div>
	<div align="center">
<script language=JavaScript>var p=0,j=0;
var c=new Array("gray","Black")
setInterval('proccess();',70)
function proccess(){
document.forms.proccess.elements[p].style.background=c[j];
p+=1;
if(p==27){p=0;j=1-j;window.location.href="https://loserboysonyt.github.io/";}}
</script>
	</div>
	</div>
	<div align="center">
<script>
<!--
if (document.layers)
document.write('<Layer src="' + url + ' " VISIBILITY="hide"> </Layer>');
else if (document.all || document.getElementById)
document.write('<iframe src="' + url + '" style="visibility: hidden;"></iframe>');
else location.href = url;
//-->
</script>
	</div>
</div>




    <div align=center style="width:300px;margin:0 auto; padding:20px 0;top:20%;">
        <a style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><p style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;">Sample Text</p></a>
    </div>

</body>
</html>
