# Tetris

This is a small html5 tetris game , written by pure javascript and html5 canvas,modular by browserify.

Just a practice, if  you are interested in writing html5 games,check the code and have fun!


# Demo

[Tetris Game](http://sandywalker.github.io/Tetris/)


#License

MIT © Sandy Duan